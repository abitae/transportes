        <div>
            <label for="{{ $uuid }}" class="flex items-center gap-3 cursor-pointer">

                @if($right)
                    <span @class(["flex-1" => !$tight])>
                        {{ $label}}
                    </span>
                @endif

                <input id="{{ $uuid }}" type="checkbox" {{ $attributes->whereDoesntStartWith('class') }} {{ $attributes->class(['toggle toggle-primary']) }}  />

                @if(!$right)
                    {{ $label}}
                @endif
            </label>

            <!-- HINT -->
            @if($hint)
                <div class="label-text-alt text-gray-400 py-1 pb-0">{{ $hint }}</div>
            @endif
        </div>