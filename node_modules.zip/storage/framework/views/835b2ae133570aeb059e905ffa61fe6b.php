    <div
            x-data="{
                    steps: [],
                    current: <?php if ((object) ($attributes->wire('model')) instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($attributes->wire('model')->value()); ?>')<?php echo e($attributes->wire('model')->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($attributes->wire('model')); ?>')<?php endif; ?>,
                    init() {
                        // Fix weird issue when navigating back
                        document.addEventListener('livewire:navigating', () => {
                            document.querySelectorAll('.step').forEach(el =>  el.remove());
                        });
                    }
            }"
        >
            <!-- STEP LABELS -->
            <ul class="steps">
                <template x-for="(step, index) in steps" :key="index">
                    <li x-html="step.text" :data-content="step.dataContent || (index + 1)" class="step" :class="(index + 1 <= current) && '<?php echo e($stepsColor); ?> ' + step.classes"></li>
                </template>
            </ul>

            <!-- STEP PANELS-->
            <div <?php echo e($attributes->whereDoesntStartWith('wire')); ?>>
                <?php echo e($slot); ?>

            </div>

            <!-- Force Tailwind compile steps color -->
            <span class="hidden step-primary step-error step-neutral step-info step-accent"></span>
        </div><?php /**PATH C:\Proyectos\transportes\storage\framework\views/92e7d4efde2c18d2539dd6d650383a9a.blade.php ENDPATH**/ ?>