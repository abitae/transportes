<svg class="inline w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path d="M3.75 7.25a.75.75 0 0 0 0 1.5h8.5a.75.75 0 0 0 0-1.5h-8.5Z"/>
</svg><?php /**PATH C:\Proyectos\transportes\storage\framework\views/86ff57505c67774d6807f9ec2a03b3b9.blade.php ENDPATH**/ ?>