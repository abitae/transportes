    <div <?php echo e($attributes->except('wire:model')); ?>>
        <div
            x-data="{
                    value: <?php if ((object) ($attributes->wire('model')) instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($attributes->wire('model')->value()); ?>')<?php echo e($attributes->wire('model')->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($attributes->wire('model')); ?>')<?php endif; ?>,
                    inputs: [],
                    init() {
                        // Copy & Paste
                        document.getElementById('pin<?php echo e($uuid); ?>').addEventListener('paste', (e) => {
                            const paste = (e.clipboardData || window.clipboardData).getData('text');

                             for (var i = 0; i < <?php echo e($size); ?>; i++) {
                                this.inputs[i] = paste[i];
                            }

                            e.preventDefault()
                            this.handlePin()
                        })
                    },
                    next(el) {
                        this.handlePin()

                        if (el.value.length == 0) {
                            return
                        }

                        if (el.nextElementSibling) {
                            el.nextElementSibling.focus()
                            el.nextElementSibling.select()
                        }
                    },
                    remove(el, i) {
                        this.inputs[i] = ''
                        this.handlePin()

                        if (el.previousElementSibling) {
                            el.previousElementSibling.focus()
                            el.previousElementSibling.select()
                        }
                    },
                    handlePin() {
                        this.value = this.inputs.join('')

                        this.value.length === <?php echo e($size); ?>

                            ? this.$dispatch('completed', this.value)
                            : this.$dispatch('incomplete', this.value)
                    }
            }"
        >
            <div class="flex gap-3" id="pin<?php echo e($uuid); ?>">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = range(0, $size - 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input
                        id="<?php echo e($uuid); ?>-pin-<?php echo e($i); ?>"
                        type="text"
                        class="input input-primary !w-14 font-black text-2xl text-center"
                        maxlength="1"
                        x-model="inputs[<?php echo e($i); ?>]"
                        @keydown.space.prevent
                        @keydown.backspace.prevent="remove($event.target, <?php echo e($i); ?>)"
                        @input="next($event.target)"
                        <?php if($numeric): ?>
                            inputmode="password"
                            x-mask="9"
                        <?php endif; ?> />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div><?php /**PATH C:\Proyectos\transportes\storage\framework\views/b3c7a05a2afd2b6319a7eb0c71d15407.blade.php ENDPATH**/ ?>