<div>
    <?php if (isset($component)) { $__componentOriginal7f194736b6f6432dc38786f292496c34 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f194736b6f6432dc38786f292496c34 = $attributes; } ?>
<?php $component = Mary\View\Components\Card::resolve(['title' => ''.e($title).'','subtitle' => ''.e($sub_title).'','separator' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mary-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('menu', null, []); ?> 
            <!-- Opcional: agregar elementos de menú aquí -->
         <?php $__env->endSlot(); ?>
        <?php
        $headers = [
            ['key' => 'id', 'label' => '#', 'class' => 'bg-green-500 w-1 text-white'],
            ['key' => 'fecha', 'label' => 'Fecha', 'class' => ''],
            ['key' => 'sucursal', 'label' => 'Sucursal', 'class' => ''],
            ['key' => 'destino', 'label' => 'Destino', 'class' => ''],
            ['key' => 'excel', 'label' => 'Excel', 'class' => ''],
        ];
        ?>
        <?php if (isset($component)) { $__componentOriginal8fbd727209323874b055feef49197909 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fbd727209323874b055feef49197909 = $attributes; } ?>
<?php $component = Mary\View\Components\Table::resolve(['headers' => $headers,'rows' => $manifiestos,'striped' => true,'withPagination' => true,'perPage' => 'perPage','perPageValues' => [5, 20, 10, 50]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mary-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__bladeCompiler = $__bladeCompiler ?? null; $loop = null; $__env->slot('cell_fecha', function($stuff) use ($__env,$__bladeCompiler) { $loop = (object) $__env->getLoopStack()[0] ?>
            <div class="text-xs"><?php echo e($stuff->created_at->format('d-m-Y H:i A')); ?></div>
            <?php }); ?>
            <?php $__bladeCompiler = $__bladeCompiler ?? null; $loop = null; $__env->slot('cell_sucursal', function($stuff) use ($__env,$__bladeCompiler) { $loop = (object) $__env->getLoopStack()[0] ?>
            <div class="text-xs"><?php echo e($stuff->sucursal->name); ?></div>
            <?php }); ?>
            <?php $__bladeCompiler = $__bladeCompiler ?? null; $loop = null; $__env->slot('cell_destino', function($stuff) use ($__env,$__bladeCompiler) { $loop = (object) $__env->getLoopStack()[0] ?>
            <div class="text-xs"><?php echo e($stuff->destino->name); ?></div>
            <?php }); ?>
            <?php $__bladeCompiler = $__bladeCompiler ?? null; $loop = null; $__env->slot('cell_excel', function($stuff) use ($__env,$__bladeCompiler) { $loop = (object) $__env->getLoopStack()[0] ?>
            <?php if (isset($component)) { $__componentOriginal602b228a887fab12f0012a3179e5b533 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal602b228a887fab12f0012a3179e5b533 = $attributes; } ?>
<?php $component = Mary\View\Components\Button::resolve(['icon' => 'o-document-arrow-down','noWireNavigate' => true,'spinner' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '_blank','wire:click' => 'excelGenerate('.e($stuff->id).')','class' => 'text-white bg-orange-500 btn-xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $attributes = $__attributesOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__attributesOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $component = $__componentOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__componentOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
            <?php }); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fbd727209323874b055feef49197909)): ?>
<?php $attributes = $__attributesOriginal8fbd727209323874b055feef49197909; ?>
<?php unset($__attributesOriginal8fbd727209323874b055feef49197909); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fbd727209323874b055feef49197909)): ?>
<?php $component = $__componentOriginal8fbd727209323874b055feef49197909; ?>
<?php unset($__componentOriginal8fbd727209323874b055feef49197909); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f194736b6f6432dc38786f292496c34)): ?>
<?php $attributes = $__attributesOriginal7f194736b6f6432dc38786f292496c34; ?>
<?php unset($__attributesOriginal7f194736b6f6432dc38786f292496c34); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f194736b6f6432dc38786f292496c34)): ?>
<?php $component = $__componentOriginal7f194736b6f6432dc38786f292496c34; ?>
<?php unset($__componentOriginal7f194736b6f6432dc38786f292496c34); ?>
<?php endif; ?>
</div><?php /**PATH C:\Proyectos\transportes\resources\views/livewire/package/manifiesto-live.blade.php ENDPATH**/ ?>