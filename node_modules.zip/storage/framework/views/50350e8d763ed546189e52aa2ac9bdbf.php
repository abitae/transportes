<table>
    <tbody>
        <tr>
            <th colspan="5">9/2/2024</th>
        </tr>
        <tr>
            <td colspan="1">
            </td>
            <th>CONDUCTOR
            </th>
            <td>GUMERCINDO LEONCIO VELAZQUE SAVALA
            </td>
            <th>MARCA DEL VEHICULO
            </th>
            <td> HINO
            </td>
        </tr>
        <tr>
            <td colspan="1">
            </td>
            <th>DNI
            </th>
            <td>21120418
            </td>
            <th>CONFIGURACION VEHICULAR
            </th>
            <td>N-3
            </td>
        </tr>
        <tr>
            <td colspan="1">
            </td>
            <th>PLACA
            </th>
            <td>W7L-874
            </td>
            <th>MTC
            </th>
            <td>1553682
            </td>
        </tr>
        <tr>
            <td colspan="1">
            </td>
            <th>LICENCIA
            </th>
            <td>Q21120418
            </td>
            <th>TELEF
            </th>
            <td>1553682
            </td>
        </tr>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th>NRO GUIA
            </th>
            <th>GUIA CLIENTE
            </th>
            <th>DESTINATARIO</th>
            <th>TELEFONO</th>
            <th>REMITENTE</th>
            <th>CANTIDAD</th>
            <th>PAQUETES</th>
            <th>MONTO</th>
            <th>RETORNO</th>
            <th>PAGO</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $encomiendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encomiendaLibre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($encomiendaLibre->code); ?></td>
            <td><?php echo e($encomiendaLibre->doc_traslado ?? 'S/D'); ?></td>
            <td><?php echo e($encomiendaLibre->remitente->name); ?></td>
            <td><?php echo e($encomiendaLibre->remitente->phone); ?></td>
            <td><?php echo e($encomiendaLibre->destinatario->name); ?></td>
            <td><?php echo e($encomiendaLibre->cantidad); ?></td>
            <td>
                <?php
                $packsLibre = '';
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $encomiendaLibre->paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo e($packsLibre.''.$paquete->description.'('.$paquete->cantidad.')'.'('.$paquete->amount.')-'); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </td>
            <td>
                <?php echo e($encomiendaLibre->monto); ?>

            </td>
            <td>
                <?php echo e($encomiendaLibre->isReturn ? 'SI' : 'NO'); ?>

            </td>
            <td>
                <?php echo e($encomiendaLibre->estado_pago); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th>NRO GUIA</th>
            <th>GUIA CLIENTE</th>
            <th>DESTINATARIO</th>
            <th>TELEFONO</th>
            <th>REMITENTE</th>
            <th>CANTIDAD</th>
            <th>PAQUETES</th>
            <th>MONTO</th>
            <th>RETORNO</th>
            <th>PAGO</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $encomiendasIsHome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encomienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($encomienda->code); ?></td>
            <td><?php echo e($encomienda->doc_traslado ?? 'S/D'); ?></td>
            <td><?php echo e($encomienda->remitente->name); ?></td>
            <td><?php echo e($encomienda->remitente->phone); ?></td>
            <td><?php echo e($encomienda->destinatario->name); ?></td>
            <td><?php echo e($encomienda->cantidad); ?></td>
            <td>
                <?php
                $packs = '';
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $encomienda->paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo e($packs.''.$paquete->description.'('.$paquete->cantidad.')'.'('.$paquete->amount.')-'); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </td>
            <td>
                <?php echo e($encomienda->monto); ?>

            </td>
            <td>
                <?php echo e($encomienda->isReturn ? 'SI' : 'NO'); ?>

            </td>
            <td>
                <?php echo e($encomienda->estado_pago); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th>NRO GUIA</th>
            <th>GUIA CLIENTE</th>
            <th>DESTINATARIO</th>
            <th>TELEFONO</th>
            <th>REMITENTE</th>
            <th>CANTIDAD</th>
            <th>PAQUETES</th>
            <th>MONTO</th>
            <th>RETORNO</th>
            <th>PAGO</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $encomiendasIsReturn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encomiendaReturn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($encomiendaReturn->code); ?></td>
            <td><?php echo e($encomiendaReturn->doc_traslado ?? 'S/D'); ?></td>
            <td><?php echo e($encomiendaReturn->remitente->name); ?></td>
            <td><?php echo e($encomiendaReturn->remitente->phone); ?></td>
            <td><?php echo e($encomiendaReturn->destinatario->name); ?></td>
            <td><?php echo e($encomiendaReturn->cantidad); ?></td>
            <td>
                <?php
                $packs = '';
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $encomiendaReturn->paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo e($packs.''.$paquete->description.'('.$paquete->cantidad.')'.'('.$paquete->amount.')-'); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </td>
            <td>
                <?php echo e($encomiendaReturn->monto); ?>

            </td>
            <td>
                <?php echo e($encomiendaReturn->isReturn ? 'SI' : 'NO'); ?>

            </td>
            <td>
                <?php echo e($encomiendaReturn->estado_pago); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Proyectos\transportes\resources\views/report/excel/manifiesto.blade.php ENDPATH**/ ?>