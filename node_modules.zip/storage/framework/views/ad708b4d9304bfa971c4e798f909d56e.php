        <div>
            <label for="<?php echo e($uuid); ?>" class="flex items-center gap-3 cursor-pointer">

                <!--[if BLOCK]><![endif]--><?php if($right): ?>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(["flex-1" => !$tight]); ?>">
                        <?php echo e($label); ?>

                    </span>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <input id="<?php echo e($uuid); ?>" type="checkbox" <?php echo e($attributes->whereDoesntStartWith('class')); ?> <?php echo e($attributes->class(['toggle toggle-primary'])); ?>  />

                <!--[if BLOCK]><![endif]--><?php if(!$right): ?>
                    <?php echo e($label); ?>

                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </label>

            <!-- HINT -->
            <!--[if BLOCK]><![endif]--><?php if($hint): ?>
                <div class="label-text-alt text-gray-400 py-1 pb-0"><?php echo e($hint); ?></div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div><?php /**PATH C:\Proyectos\transportes\storage\framework\views/31918d6bc616e99e6fd4014e808a9af6.blade.php ENDPATH**/ ?>