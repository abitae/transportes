        <div
            class="hidden"
            x-init="steps.push({ step: '<?php echo e($step); ?>', text: '<?php echo e($text); ?>', classes: '<?php echo e($stepClasses); ?>' <?php if($dataContent): ?>, dataContent: '<?php echo e($dataContent); ?>' <?php endif; ?> })"
        ></div>

        <div x-show="current == '<?php echo e($step); ?>'" <?php echo e($attributes->class("px-1")); ?> >
            <?php echo e($slot); ?>

        </div><?php /**PATH C:\Proyectos\transportes\storage\framework\views/06bdffb8746f2ed95fa4bcd6ef7b56b7.blade.php ENDPATH**/ ?>