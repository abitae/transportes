<img src="./img/logo01.png" alt="Infinity" width="200" height="60">
<?php /**PATH C:\Proyectos\transportes\resources\views/components/application-logo.blade.php ENDPATH**/ ?>