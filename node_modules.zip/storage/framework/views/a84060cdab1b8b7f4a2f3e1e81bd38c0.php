<!--Start Banner Two-->
<section class="banner-two">
    <div class="banner-two__img1 float-bob-y">
        <div class="inner">
            <img src="web2/assets/images/banner/banner-v2-img1.jpg" alt="">
        </div>
    </div>
    <div class="banner-two__img2 float-bob-x"><img src="web2/assets/images/banner/banner-v2-img2.png" alt="">
    </div>
    <div class="shape1 float-bob-y"><img src="web2/assets/images/shapes/banner-v2-shape1.png" alt=""></div>
    <div class="shape2"><img src="web2/assets/images/shapes/banner-v2-shape2.png" alt=""></div>
    <div class="container clearfix">
        <div class="banner-two__content">
            <div class="banner-two__content-top wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                <div class="title-box">
                    <h2>EXPERTOS TRANSPORTE <br> <span>CARGO</span></h2>
                </div>
            </div>

            <div class="banner-two__content-bottom wow fadeInRight" data-wow-delay="0ms"
                data-wow-duration="1500ms">
                <div class="text-box">
                    <p>Si tienes un paquete y quieres saber cuál es su última actualización, consulta la última actualización
                        con el ID de tu paquete en el formulario que aparece a continuación. Gracias.</p>
                </div>
                
            </div>
        </div>
    </div>
</section>
<!--End Banner Two--><?php /**PATH C:\Proyectos\transportes\resources\views/web2/partial/banner.blade.php ENDPATH**/ ?>