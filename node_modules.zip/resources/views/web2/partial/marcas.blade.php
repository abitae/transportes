<!--Start Brand One-->
<section class="brand-one">
    <div class="container">
        <div class="brand-one__carousel owl-carousel owl-theme">
            <!--Start Brand One Single-->
            <div class="brand-one__single">
                <div class="brand-one__single-inner">
                    <a href="#"><img src="web2/assets/images/brand/brand-v1-img1.png" alt=""></a>
                </div>
            </div>
            <!--End Brand One Single-->

            <!--Start Brand One Single-->
            <div class="brand-one__single">
                <div class="brand-one__single-inner">
                    <a href="#"><img src="web2/assets/images/brand/brand-v1-img2.png" alt=""></a>
                </div>
            </div>
            <!--End Brand One Single-->

            <!--Start Brand One Single-->
            <div class="brand-one__single">
                <div class="brand-one__single-inner">
                    <a href="#"><img src="web2/assets/images/brand/brand-v1-img3.png" alt=""></a>
                </div>
            </div>
            <!--End Brand One Single-->

            <!--Start Brand One Single-->
            <div class="brand-one__single">
                <div class="brand-one__single-inner">
                    <a href="#"><img src="web2/assets/images/brand/brand-v1-img4.png" alt=""></a>
                </div>
            </div>
            <!--End Brand One Single-->

            <!--Start Brand One Single-->
            <div class="brand-one__single">
                <div class="brand-one__single-inner">
                    <a href="#"><img src="web2/assets/images/brand/brand-v1-img5.png" alt=""></a>
                </div>
            </div>
            <!--End Brand One Single-->

            <!--Start Brand One Single-->
            <div class="brand-one__single">
                <div class="brand-one__single-inner">
                    <a href="#"><img src="web2/assets/images/brand/brand-v1-img6.png" alt=""></a>
                </div>
            </div>
            <!--End Brand One Single-->
        </div>
    </div>
</section>
<!--End Brand One-->