<!-- Start Preloader -->
<div class="loader-wrap">
    <div class="preloader">
        <div class="preloader-close">x</div>
        <div id="handle-preloader" class="handle-preloader">
            <div class="animation-preloader">
                <div class="spinner"></div>
                <div class="txt-loading">
                    <span data-text-preloader="b" class="letters-loading"> b </span>
                    <span data-text-preloader="r" class="letters-loading"> r </span>
                    <span data-text-preloader="a" class="letters-loading"> a </span>
                    <span data-text-preloader="y" class="letters-loading"> y </span>
                    <span data-text-preloader="a" class="letters-loading"> a </span>
                    <span data-text-preloader="n" class="letters-loading"> n </span>
                    <span data-text-preloader="-" class="letters-loading"> - </span>
                    <span data-text-preloader="b" class="letters-loading"> b </span>
                    <span data-text-preloader="r" class="letters-loading"> r </span>
                    <span data-text-preloader="u" class="letters-loading"> u </span>
                    <span data-text-preloader="s" class="letters-loading"> s </span>
                    <span data-text-preloader="h" class="letters-loading"> h </span>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Preloader -->